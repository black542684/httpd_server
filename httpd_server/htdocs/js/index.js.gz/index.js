window.onload = function () {
  const div = document.createElement("div");
  div.innerHTML = "This is div";
  document.body.appendChild(div);
}